---
title: Structure Aware Category-level 6D Object Pose Estimation
date: 2022-01-27 21:48:57
tags:
---

<strong>Description:</strong>

Category-level object pose estimation networks outperform instance-level 6d pose estimation networks in terms of supporting objects [1] and get more and more attention in the computer vision community. However, current monocular methods suffer from scale ambiguities of objects. The student should disambiguate the scales of category-level objects by exploring structure information such as supporting planes, in order to get physically-correct outcomes from the network.



Requirement: </strong>

Students should be familiar with pytorch or tensorflow and have hands-on experience with deep learning in past projects. Aiming for a paper publication would be a plus.





[1] Manhardt, Fabian, et al. "CPS++: Improving Class-level 6D Pose and Shape Estimation From Monocular Images With Self-Supervised Learning." *arXiv preprint arXiv:2003.05848* (2020).